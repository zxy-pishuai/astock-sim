# 1.0 实现进度

!!! note "历史实现记录"
    本页记录 `eltdx 1.0` 的实现过程，不是当前 `v2.0.5` API 使用说明。当前用法请查看 [API 参考](API_REFERENCE.md) 和 [调用方法](METHOD_REFERENCE.md)。

这份文档记录 `eltdx 1.0` 已接入的模块和验证进度。

## 项目重建

状态：已完成。

目标：

- 建立干净的 PyPI 项目目录。
- 固定 `TdxClient` 和业务 API 形状。
- 建立 19 个 `7709` 命令注册表。
- 建立中文产品文档。

## 底层 Transport

状态：`SocketTransport`、连接池包装和主站 TCP 测速已完成首版。

当前实现：

| 模块 | 位置 |
| --- | --- |
| 二进制帧构造和解析 | `src/eltdx/protocol/frame.py` |
| socket 门面、Actor 请求入口和诊断快照 | `src/eltdx/transport/socket.py` |
| FIFO 连接池和 lease 调度 | `src/eltdx/transport/pool.py` |
| 主站列表和 TCP 测速 | `src/eltdx/hosts.py` |

验收标准：

- 可以连接 7709 主站。已完成。
- 可以握手。已完成。
- 可以心跳。已完成。
- 可以发送命令并校验 `msg_id` 和 `msg_type`。已完成。
- `pool_size=N` 创建 N 个连接槽位，请求通过全池 FIFO admission 分配给首个空闲 slot。已完成。
- 可以在启动前按 TCP 连接延迟排序主站。已完成。
- 推送类接口已经有 reader / push queue 首版。

## 核心行情命令

状态：主动查询类核心命令已完成。

优先顺序：

1. `0x044e` 代码数量
2. `0x044d` 代码表分页
3. `0x054c` 批量行情快照
4. `0x054b` 分类行情列表
5. `0x052d` K线
6. `0x0537` 当日分时
7. `0x0fb4` 历史分时
8. `0x0fc5` 当日成交明细
9. `0x0547` 行情增量刷新

当前进度：

| 命令 | 状态 |
| --- | --- |
| `0x044e` | 已完成构包、解析、测试、真实主站小样本验证 |
| `0x044d` | 已完成构包、解析、测试、真实主站小样本验证 |
| `0x054c` | 已完成构包、解析、测试、真实主站小样本验证 |
| `0x054b` | 已完成构包、解析、测试、真实主站小样本验证 |
| `0x052d` | 已完成构包、解析、测试、真实主站小样本验证 |
| `0x0537` | 已完成构包、解析、测试、真实主站小样本验证 |
| `0x0fb4` | 已完成构包、解析、测试、真实主站小样本验证 |
| `0x0fc5` | 已完成构包、解析、测试、真实主站小样本验证 |
| `0x0547` | 单次刷新和推送队列已完成；单次最多 100 个代码 |

验收标准：

- 每个命令有请求构造、响应解析、样本测试。
- 字段名和中文含义能追溯到 `7709` 文档。
- 对外 API 返回稳定模型。

## 增强命令

状态：主动查询类增强命令已完成。

增强命令：

- `0x056a` 集合竞价明细
- `0x0fc6` 历史成交明细增强
- `0x0feb` 近期历史分时
- `0x051b` 分时副图
- `0x0fd1` 小走势图
- `0x000f` 股本变迁
- `0x0010` 财务信息批量
- `0x0452` 特殊品种涨跌停限制

这些接口已完成构包、解析、单元测试，并用真实主站小样本验证过。

## 推送队列

已完成：

- `Slot task`：每个连接槽位独占非阻塞 socket、decoder 和 TCP generation，由 Engine 的共享 Tokio worker 调度。
- 请求配对：响应同时校验 runtime epoch、TCP generation、socket identity、lease、`msg_id` 和 `msg_type`。
- 有界 push buffer：`msg_id=0` 或未配对推送帧进入 pool epoch 共享队列，溢出时显式报告 gap。

对外读取方法：

- `client.quotes.poll_push()`
- `client.quotes.drain_pushes()`

## 便捷 API

状态：首版已完成。

已补回：

- 批量快照 `get_quote()`，自动拆批。
- 代码表和常用代码过滤方法。
- K 线、分时、成交明细的旧式方法名和分页聚合。
- 集合竞价明细和 09:25 竞价成交快照。
- `get_gbbq()`。
- `get_xdxr()`、`get_equity()`、`get_turnover()`、`get_factors()`。
- 默认 `TdxClient()` 真实连接，`TdxClient.in_memory()` 测试用。
- 连接池和主站测速。
- 部分调试入口支持 `include_raw`。
- `to_jsonable()` / `to_json()`。
- `eltdx-mcp` MCP 工具服务。

## 7615 F10 / HTTP 资料

状态：首版已完成。

| 能力 | 状态 |
| --- | --- |
| 通用 TQLEX Entry 调用 | 已完成 |
| ResultSets 表格解析 | 已完成，支持重复列名 |
| 常用中文封装 | 已完成 |
| 真实网关小样本 | 已验证公司概况、热点题材、公告、题材行情、估值 |

## 工具和扩展

| 模块 | 说明 |
| --- | --- |
| `equity` | 本地复权因子、股本和换手率计算 |
| `mcp` | 已接入 MCP stdio 工具服务 |
| `scripts` | smoke、字段验证、样本导出 |
